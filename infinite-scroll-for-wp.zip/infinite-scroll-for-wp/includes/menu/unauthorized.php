<?php

function ikva_infinite_scroll_for_wp_unauthorized() {
    echo '<div class="notice-error notice"><p><strong> ✋ Stop: You are not allowed to access this tab 👻</strong></p></div><style>.ikva-infinite-scroll-tabs{display: none}</style>';
}
